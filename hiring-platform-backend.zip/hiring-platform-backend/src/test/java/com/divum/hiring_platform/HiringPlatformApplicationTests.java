package com.divum.hiring_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HiringPlatformApplicationTests {

//	@Test
//	void contextLoads() {
//
//	}
}
