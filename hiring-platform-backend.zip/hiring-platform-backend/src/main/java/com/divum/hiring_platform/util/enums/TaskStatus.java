package com.divum.hiring_platform.util.enums;

public enum TaskStatus {

    SUCCESS,
    PENDING,
    RETRY,
    ADMIN_NOTIFIED,
    FAILED
}
