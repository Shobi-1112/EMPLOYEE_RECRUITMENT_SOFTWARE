package com.divum.hiring_platform.util.enums;

public enum Difficulty {

    EASY,
    MEDIUM,
    HARD
}
