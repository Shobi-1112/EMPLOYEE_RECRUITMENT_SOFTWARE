package com.divum.hiring_platform.util.enums;


public enum CasesType {

    SAMPLE,
    HIDDEN
}
