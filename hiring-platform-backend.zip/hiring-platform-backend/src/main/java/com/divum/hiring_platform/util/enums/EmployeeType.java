package com.divum.hiring_platform.util.enums;



public enum EmployeeType {

    TECHNICAL_HR,
    PERSONAL_HR
}
