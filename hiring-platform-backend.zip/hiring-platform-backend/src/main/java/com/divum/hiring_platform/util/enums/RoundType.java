package com.divum.hiring_platform.util.enums;

public enum RoundType {

    MCQ,
    CODING,
    TECHNICAL_INTERVIEW,
    PERSONAL_INTERVIEW
}
