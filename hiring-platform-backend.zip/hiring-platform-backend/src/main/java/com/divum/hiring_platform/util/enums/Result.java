package com.divum.hiring_platform.util.enums;

public enum Result {
    PASS,
    FAIL
}
