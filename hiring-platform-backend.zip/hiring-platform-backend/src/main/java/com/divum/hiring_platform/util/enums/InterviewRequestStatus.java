package com.divum.hiring_platform.util.enums;

public enum InterviewRequestStatus {

    APPLIED,
    REASSIGNED,
    RESCHEDULED,
    REJECTED
}
