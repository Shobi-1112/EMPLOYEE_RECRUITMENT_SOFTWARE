package com.divum.hiring_platform.util.enums;


public enum InterviewRequestType {

    RESCHEDULE,
    CANCEL
}
