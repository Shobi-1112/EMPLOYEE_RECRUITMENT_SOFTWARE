package com.divum.hiring_platform.util.enums;

public enum TypeStatus {

    COMPLETED,
    UNCOMPLETED
}
