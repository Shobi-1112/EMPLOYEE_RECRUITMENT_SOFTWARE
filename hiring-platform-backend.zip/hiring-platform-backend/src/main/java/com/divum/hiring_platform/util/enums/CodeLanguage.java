package com.divum.hiring_platform.util.enums;

public enum CodeLanguage {

    JAVA,
    PYTHON,
    C,
    CPP
}
