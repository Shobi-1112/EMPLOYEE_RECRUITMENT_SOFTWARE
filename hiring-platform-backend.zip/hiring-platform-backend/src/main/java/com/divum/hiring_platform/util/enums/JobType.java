package com.divum.hiring_platform.util.enums;

public enum JobType {

    INTERVIEW_REQUEST
}
