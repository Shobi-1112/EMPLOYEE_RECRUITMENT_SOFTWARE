package com.divum.hiring_platform.util.enums;

public enum Stack {

    JAVA,
    PYTHON,
    REACTJS
}
