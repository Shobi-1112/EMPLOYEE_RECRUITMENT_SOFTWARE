package com.divum.hiring_platform.util.enums;

public enum ContestStatus {

    UPCOMING,
    CURRENT,
    COMPLETED
}
