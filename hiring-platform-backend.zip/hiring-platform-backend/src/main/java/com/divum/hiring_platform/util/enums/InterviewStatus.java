package com.divum.hiring_platform.util.enums;

public enum InterviewStatus {

    PENDING,
    CONFIRMED,
    REJECTED

}
