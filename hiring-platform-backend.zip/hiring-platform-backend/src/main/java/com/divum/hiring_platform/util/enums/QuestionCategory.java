package com.divum.hiring_platform.util.enums;

public enum QuestionCategory {
    APTITUDE_MCQ,
    LOGICAL_MCQ,
    VERBAL_MCQ,
    TECHNICAL_MCQ,
    DATA_STRUCTURE_CODING,
    ALGORITHMS_CODING,
    MATHEMATICS_CODING,
    STRINGS_CODING,
    PATTERN_CODING
}
