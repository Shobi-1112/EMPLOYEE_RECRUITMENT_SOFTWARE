package com.divum.hiring_platform.util.enums;

public enum EmployeeResponse {
    AVAILABLE,
    PENDING,
    NOT_AVAILABLE,
    NO_RESPONSE
}
