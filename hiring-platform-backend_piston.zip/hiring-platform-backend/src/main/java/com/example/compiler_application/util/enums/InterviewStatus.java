package com.example.compiler_application.util.enums;

public enum InterviewStatus {

    PENDING,
    CONFIRMED,
    REJECTED

}
