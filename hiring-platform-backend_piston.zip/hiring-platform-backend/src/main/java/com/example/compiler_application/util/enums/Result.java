package com.example.compiler_application.util.enums;

public enum Result {
    PASS,
    FAIL
}
