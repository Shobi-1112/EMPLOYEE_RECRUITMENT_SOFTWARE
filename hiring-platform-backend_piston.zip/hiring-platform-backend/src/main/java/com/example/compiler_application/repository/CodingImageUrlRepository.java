package com.example.compiler_application.repository;

import com.example.compiler_application.entity.CodingImageUrl;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CodingImageUrlRepository extends JpaRepository<CodingImageUrl , Long> {
}
