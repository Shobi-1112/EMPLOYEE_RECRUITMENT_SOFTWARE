package com.example.compiler_application.util.enums;

public enum EmployeeResponse {
    AVAILABLE,
    PENDING,
    NOT_AVAILABLE,
    NO_RESPONSE
}
