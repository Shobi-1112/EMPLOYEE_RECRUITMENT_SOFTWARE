package com.example.compiler_application.util.enums;

public enum TaskStatus {

    SUCCESS,
    PENDING,
    RETRY,
    FAILED,
    ADMIN_NOTIFIED
}
