package com.example.compiler_application.util.enums;

public enum RoundType {

    MCQ,
    CODING,
    TECHNICAL_INTERVIEW,
    PERSONAL_INTERVIEW
}
