package com.example.compiler_application.entity;


import com.example.compiler_application.util.enums.RoundType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@Entity
@Builder
@NoArgsConstructor
@Table(name = "round")
public class Rounds {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Enumerated(EnumType.STRING)
    private RoundType roundType;

    @ManyToOne
    @JoinColumn(name = "contest_id", nullable = false)
    private Contest contest;

    private int participantsCounts;


    @OneToMany(mappedBy = "rounds", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonIgnoreProperties("rounds")
    private List<Part> parts;

    @OneToMany(mappedBy = "rounds", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnoreProperties("rounds")
    private List<EmailTask> emailTasks;


    @OneToMany(mappedBy = "rounds")
    @JsonIgnore
    private List<Interview> interviews;

    private LocalDateTime startTime;
    private LocalDateTime endTime;

    @Override
    public String toString() {
        return "Rounds{" +
                "id='" + id + '\'' +
                ", roundType=" + roundType +
                ", contest=" + contest.getContestId() +
                ", participantsCounts=" + participantsCounts +
                ", parts=" + parts +
                ", emailTasks=" + emailTasks +
                ", interviews=" + interviews +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", roundNumber=" + roundNumber +
                ", passCount=" + passCount +
                ", passPercentage=" + passPercentage +
                '}';
    }

    private int roundNumber;
    private int passCount;
    private int passPercentage;
}