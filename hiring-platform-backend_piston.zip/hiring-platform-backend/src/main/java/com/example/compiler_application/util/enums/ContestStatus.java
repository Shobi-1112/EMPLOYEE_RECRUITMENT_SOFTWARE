package com.example.compiler_application.util.enums;

public enum ContestStatus {

    UPCOMING,
    CURRENT,
    COMPLETED
}
