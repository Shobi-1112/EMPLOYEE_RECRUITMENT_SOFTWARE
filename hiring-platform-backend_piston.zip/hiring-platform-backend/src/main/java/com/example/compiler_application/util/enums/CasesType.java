package com.example.compiler_application.util.enums;

public enum CasesType {
    SAMPLE,
    HIDDEN
}
