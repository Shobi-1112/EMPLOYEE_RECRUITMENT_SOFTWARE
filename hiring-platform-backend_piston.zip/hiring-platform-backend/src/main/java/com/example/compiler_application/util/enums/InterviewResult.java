package com.example.compiler_application.util.enums;

public enum InterviewResult {

    SELECTED,
    CAN_BE_CONSIDERATE,
    REJECTED
}
