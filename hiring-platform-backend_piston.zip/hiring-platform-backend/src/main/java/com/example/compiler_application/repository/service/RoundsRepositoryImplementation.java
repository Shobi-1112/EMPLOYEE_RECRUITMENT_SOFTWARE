package com.example.compiler_application.repository.service;

import com.example.compiler_application.entity.CodingResult;
import com.example.compiler_application.entity.Rounds;

import java.util.List;
import java.util.Optional;

public interface RoundsRepositoryImplementation {
    int getPassMark(String roundId);
    Optional<Rounds> findRounds(String roundId);

}
