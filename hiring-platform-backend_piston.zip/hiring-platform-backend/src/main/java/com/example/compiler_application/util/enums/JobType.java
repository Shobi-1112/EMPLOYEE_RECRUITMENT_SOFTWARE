package com.example.compiler_application.util.enums;

public enum JobType {

    INTERVIEW_REQUEST
}
