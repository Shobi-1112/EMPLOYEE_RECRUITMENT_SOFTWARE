package com.example.compiler_application.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.util.Set;


@Entity
@Table(name = "user_details")
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class User {

   @Id
   @GeneratedValue(strategy = GenerationType.UUID)
   private String userId;

   @Column(unique = true)
   private String email;

   private String name;

   private String password;
   private String collegeName;

   @JsonIgnore
   @ManyToMany(fetch = FetchType.EAGER)
   @JoinTable(
           name = "contest_user",
           joinColumns = @JoinColumn(name = "user_id"),
           inverseJoinColumns = @JoinColumn(name = "contest_id")
   )
   private Set<Contest> contest;

   @OneToOne(mappedBy = "user")
   @JsonIgnore
   private Resume resume;

   private boolean isPassed;

   @Override
   public String toString() {
      return "User{" +
              "userId='" + userId + '\'' +
              ", email='" + email + '\'' +
              ", name='" + name + '\'' +
              ", password='" + password + '\'' +
              ", collegeName='" + collegeName + '\'' +
              ", isPassed=" + isPassed +
              '}';
   }
}