package com.example.compiler_application.entity;

import com.example.compiler_application.util.enums.Result;

public interface ResultEntity {
        String getId();
        String getContestId();
        String getRoundId();
        String getUserId();
        Result getResult();

        float getTotalPercentage();
}
